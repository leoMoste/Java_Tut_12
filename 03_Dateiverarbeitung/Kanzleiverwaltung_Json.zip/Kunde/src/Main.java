import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
// ui library
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Main {
    public static List<Kunde> kunden = new ArrayList<>();
    private static JTable kundenTabelle;
    private static DefaultTableModel tableModel;
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        System.out.println(date);
        UI();
        kundenLaden("kunden.json");
    }

    public static void UI() {
        JFrame frame = new JFrame("Kundenverwaltung");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(10, 10));
        frame.setSize(600, 500);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Datei");
        JMenuItem menuItemLaden = new JMenuItem("Laden");
        menuItemLaden.addActionListener(e -> kundenLaden("kunden.json"));
        menu.add(menuItemLaden);

        JMenuItem menuItemSpeichern = new JMenuItem("Speichern");
        menuItemSpeichern.addActionListener(e -> kundenSpeichern("kunden.json"));
        menu.add(menuItemSpeichern);

        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        // Table for customers
        String[] columnNames = {"Kundennummer", "Name", "Datum"};
        tableModel = new DefaultTableModel(columnNames, 0);
        kundenTabelle = new JTable(tableModel);
        kundenTabelle.setPreferredScrollableViewportSize(new Dimension(500, 70));
        kundenTabelle.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(kundenTabelle);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Panel for adding new customers
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addPanel.setBorder(BorderFactory.createTitledBorder("Kunde hinzufügen"));

        addPanel.add(new JLabel("Kundennummer:"));
        JTextField idField = new JTextField(10);
        addPanel.add(idField);

        addPanel.add(new JLabel("Name:"));
        JTextField nameField = new JTextField(20);
        addPanel.add(nameField);

        addPanel.add(new JLabel("Datum (YYYY-MM-DD):"));
        JTextField dateField = new JTextField(10);
        addPanel.add(dateField);

        JButton addButton = new JButton("Hinzufügen");
        addButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                LocalDate datum = LocalDate.parse(dateField.getText());
                kunden.add(new Kunde(id, name, datum));
                tableModel.addRow(new Object[]{id, name, datum});
                idField.setText("");
                nameField.setText("");
                dateField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Fehler beim Hinzufügen des Kunden: " + ex.getMessage());
            }
        });

        addPanel.add(addButton);
        frame.add(addPanel, BorderLayout.SOUTH);

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        frame.pack();
        frame.setMinimumSize(frame.getSize()); // This ensures that the frame cannot be resized to be smaller than needed
        frame.setVisible(true);
    }

    public static void kundenLaden(String dateiname){
        kunden = Util.kundenLadenJson(dateiname);
        Kunde[] kundenArray = kunden.toArray(new Kunde[0]);
           for (Kunde k : kundenArray) {
                tableModel.addRow(new Object[]{k.getKnr(), k.getKname(), k.getKgebdat()});
            }
    }

    public static void kundenSpeichern(String dateiname){
        Util.kundenSpeichernJson(kunden, dateiname);
    }

}
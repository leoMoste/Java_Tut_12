import java.time.LocalDate;

public class Kunde {
    private int knr;
    private String kname;
    private LocalDate kgebdat;

    public Kunde(int knr, String kname, LocalDate kgebdat) {
        this.knr = knr;
        this.kname = kname;
        this.kgebdat = kgebdat;
    }

    public int getKnr() {
        return knr;
    }

    public String getKname() {
        return kname;
    }

    public LocalDate getKgebdat() {
        return kgebdat;
    }

    public void setKnr(int knr) {
        this.knr = knr;
    }

    public void setKname(String kname) {
        this.kname = kname;
    }

    public void setKgebdat(LocalDate kgebdat) {
        this.kgebdat = kgebdat;
    }

    @Override
    public String toString() {
        return "Kunde{" +
                "knr=" + knr +
                ", kname='" + kname + '\'' +
                ", kgebdat=" + kgebdat +
                '}';
    }
}

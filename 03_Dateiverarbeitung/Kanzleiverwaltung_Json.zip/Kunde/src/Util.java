import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Util {

    public static void kundenSpeichern(List<Kunde> kunden, String dateiname) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(dateiname))) {
            for (Kunde k : kunden) {
                bw.write(k.getKnr() + ";" + k.getKname() + ";" + k.getKgebdat() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Kunde> kundenLaden(String dateiname) {
        ArrayList<Kunde> kunden = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(dateiname))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] kundenDaten = line.split(";");
                int knr = Integer.parseInt(kundenDaten[0]);
                String kname = kundenDaten[1];
                LocalDate kgebdat = LocalDate.parse(kundenDaten[2]);
                kunden.add(new Kunde(knr, kname, kgebdat));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return kunden;
    }

    public static void kundenSpeichernJson(List<Kunde> kunden, String dateiname) {
        Gson gson = new Gson();
        String json = gson.toJson(kunden);

        try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dateiname), StandardCharsets.UTF_8))) {
            writer.write(encrypt(json, 13));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Kunde> kundenLadenJson(String dateiname) {
        Gson gson = new Gson();
        try (Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream(dateiname), StandardCharsets.UTF_8))) {
            Type listType = new TypeToken<ArrayList<Kunde>>() {}.getType();
            return gson.fromJson(decrypt(reader, 13), listType);
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static String encrypt(String text, int key) {
        StringBuilder result = new StringBuilder();
        for (char character : text.toCharArray()) {
            if (character >= 'a' && character <= 'z') {
                result.append((char) ('a' + (character - 'a' + key) % 26));
            } else if (character >= 'A' && character <= 'Z') {
                result.append((char) ('A' + (character - 'A' + key) % 26));
            } else {
                result.append(character);
            }
        }
        return result.toString();
    }

    public static String decrypt(Reader reader, int key) throws IOException {
        StringBuilder result = new StringBuilder();
        int character;
        while ((character = reader.read()) != -1) {
            if (character >= 'a' && character <= 'z') {
                result.append((char) ('a' + (character - 'a' - key + 26) % 26));
            } else if (character >= 'A' && character <= 'Z') {
                result.append((char) ('A' + (character - 'A' - key + 26) % 26));
            } else {
                result.append((char) character);
            }
        }
        return result.toString();
    }
}
